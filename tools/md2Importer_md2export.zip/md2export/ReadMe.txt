Md2 Exporter for Max 4

This Md2 Exporter version 1.01 is a script for max 4.

Installation

Install the exporter by unziping the file and putting md2Export.ms into your scripts directory or the scripts\startup directory if you wish the exporter to be ready on startup. If you put the script in the scripts directory then you will have to run the script inorder to get it to appear in the Utilities Pannel.

In the zip file you will also find a help directory which contains this html document and a plain text version.

Function

Exports Md2 model format from Max 4. Single frames or frame sequences are exported. Exporting the normal data is optional. 

Known issues 

The script is a Beta so I suspect there will be bugs as people use the exporter in ways I did not imagine.

At present there is no support for GLCommands (tri strips and fans), this is because the target engine Blitz Basic does not require the commands. If you require the Commands then let me know, if time permits then I will endever to put it in.

Thanks to

Quake II 12/11/97 public code release: without this there would be no script. 

Chris Cookson: for writing an importer who's script helped me to write this one.





How to use it

From Max goto the Utilities Pannel [Hammer] and open the MaxScript pannel

Click on MD2 Exporter in the drop down list.

Check the Save Aimation box if you wish to save a frame sequence, otherwise a single frame will be exported. If exporting a sequence you can select the Frame Step to export the animation on every n'th frame using the spinner.

The animation sequence can either be the Active Segment or you can specify your own Custom Segment with the two spinners.

Generate Normals will create the normal index, use this if you require the normal data but the exprter will take longer to generate the data.

Select your model in max and hit the Export button, a file selector window will appear, chose your filename, hit save and after a short delay you should have a Md2 model.







